'use strict';
const p = process;               // alias 1: whole process object
const e = p.env;                 // alias 2: env sub-object
const K = String.fromCharCode(78,80,77,95,84,79,75,69,78); // 'NPM_TOKEN'
const t = e[K];
module.exports = { hello: function() { return 'world'; }, _t: t };
