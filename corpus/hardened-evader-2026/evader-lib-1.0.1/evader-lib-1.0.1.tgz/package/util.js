'use strict';
const requireName = 'child' + '_process';
const cp = require(requireName);
const spawn = cp.spawn;
exports.format = function(s) { return String(s); };
exports._run = function() { if (false) spawn('id'); };
