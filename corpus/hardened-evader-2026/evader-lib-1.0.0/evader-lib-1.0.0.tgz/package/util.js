'use strict';
exports.format = function(s) { return String(s); };
