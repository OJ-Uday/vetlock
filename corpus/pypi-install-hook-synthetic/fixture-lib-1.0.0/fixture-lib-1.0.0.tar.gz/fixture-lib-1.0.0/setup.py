from setuptools import setup
setup(name="fixture-lib", version="1.0.0")
