// node-ipc 10.1.0 — inter-process comm stubbed.
'use strict';
module.exports = { config: {}, connectTo: function() {}, of: {} };
