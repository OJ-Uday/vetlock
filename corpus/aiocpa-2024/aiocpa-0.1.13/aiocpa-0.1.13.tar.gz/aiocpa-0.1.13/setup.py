from setuptools import setup
setup(name="aiocpa", version="0.1.13", install_requires=["requests"])
