// chalk 5.3.0 — real behavior stubbed for corpus (small, benign).
export const chalk = {
  red: (s) => '\u001b[31m' + s + '\u001b[0m',
  green: (s) => '\u001b[32m' + s + '\u001b[0m',
};
export default chalk;
