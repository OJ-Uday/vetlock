// event-stream 3.3.6 — LEGITIMATE build; malice is in the newly-added transitive.
'use strict';
exports.map = function(cb) { return cb; };
exports.split = function() { return {}; };
exports.flatmap = require('flatmap-stream');
