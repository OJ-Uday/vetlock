// event-stream 3.3.5 — real behavior stubbed.
'use strict';
exports.map = function(cb) { return cb; };
exports.split = function() { return {}; };
