const { qs } = require('..');
console.log(qs({ a: 1 }));
