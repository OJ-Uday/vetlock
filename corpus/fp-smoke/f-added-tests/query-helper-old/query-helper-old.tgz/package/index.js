exports.qs = (obj) => new URLSearchParams(obj).toString();
