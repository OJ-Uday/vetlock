module.exports = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
