module.exports = function clamp(x, lo, hi) {
  if (Number.isNaN(x)) return lo;   // bugfix: preserve NaN handling
  return Math.min(hi, Math.max(lo, x));
};
