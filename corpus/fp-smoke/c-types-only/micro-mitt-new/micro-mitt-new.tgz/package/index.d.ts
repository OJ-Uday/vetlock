export function mitt<T = unknown>(): { on(evt: string, h: (v: T) => void): void; emit(evt: string, v: T): void };
