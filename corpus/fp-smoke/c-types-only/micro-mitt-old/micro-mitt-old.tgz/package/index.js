export const mitt = () => ({ on() {}, emit() {} });
