export function mitt(): { on(): void; emit(): void };
