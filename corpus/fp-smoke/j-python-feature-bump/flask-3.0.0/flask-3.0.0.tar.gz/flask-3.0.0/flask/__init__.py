def create_app():
    return {"version": "3.0.0"}
