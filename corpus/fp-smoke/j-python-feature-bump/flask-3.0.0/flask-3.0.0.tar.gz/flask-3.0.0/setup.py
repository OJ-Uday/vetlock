from setuptools import setup
setup(name="flask", version="3.0.0")
