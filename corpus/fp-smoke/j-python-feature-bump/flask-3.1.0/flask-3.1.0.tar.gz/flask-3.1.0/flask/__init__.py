def create_app(debug=False):
    return {"version": "3.1.0", "debug": debug}

def describe_app(name):
    return f"flask:{name}"
