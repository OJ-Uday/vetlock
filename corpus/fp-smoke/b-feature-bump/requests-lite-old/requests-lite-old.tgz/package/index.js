import https from 'https';
export function get(url) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, (res) => resolve(res));
    req.on('error', reject);
    req.end();
  });
}
