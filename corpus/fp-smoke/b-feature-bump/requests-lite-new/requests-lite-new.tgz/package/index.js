import https from 'https';
export function get(url) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, (res) => resolve(res));
    req.on('error', reject);
    req.end();
  });
}
export function post(url, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, { method: 'POST' }, (res) => resolve(res));
    req.on('error', reject);
    req.end(body);
  });
}
