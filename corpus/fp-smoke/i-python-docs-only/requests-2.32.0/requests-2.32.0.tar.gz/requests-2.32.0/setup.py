from setuptools import setup
setup(name="requests", version="2.32.0")
