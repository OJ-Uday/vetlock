'use strict';
function trim(x) { return x.trim(); }
function parse(input) {
  const parts = input.split(',');
  return parts.map(trim);
}
module.exports = { parse };
