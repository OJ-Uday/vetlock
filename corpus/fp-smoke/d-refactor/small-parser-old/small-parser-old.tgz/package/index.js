'use strict';
function parse(input) {
  return input.split(',').map(s => s.trim());
}
module.exports = { parse };
