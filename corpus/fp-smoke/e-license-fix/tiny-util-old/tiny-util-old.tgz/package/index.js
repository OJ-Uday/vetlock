module.exports = { identity: (x) => x };
