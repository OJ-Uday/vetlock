# lodash-lite v1.2.1

Small utility. Doc fix.
