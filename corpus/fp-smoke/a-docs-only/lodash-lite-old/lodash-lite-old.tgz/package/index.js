export const chunk = (arr, n) => arr.slice(0, n);
