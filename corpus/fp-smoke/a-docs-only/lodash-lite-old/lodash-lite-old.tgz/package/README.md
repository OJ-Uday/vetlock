# lodash-lite v1.2.0

Small utility.
