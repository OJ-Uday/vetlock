from setuptools import setup
setup(name="ultralytics", version="8.3.41")
