// eslint-scope 3.7.1 — real scope analyzer, stubbed for corpus.
'use strict';
module.exports = require('./lib/index.js');
