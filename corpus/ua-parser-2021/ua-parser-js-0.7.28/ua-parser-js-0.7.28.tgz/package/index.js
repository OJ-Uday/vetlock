// ua-parser-js 0.7.28 — user-agent parser (stubbed).
'use strict';
function UAParser() { return { getBrowser: function() { return {}; } }; }
module.exports = UAParser;
