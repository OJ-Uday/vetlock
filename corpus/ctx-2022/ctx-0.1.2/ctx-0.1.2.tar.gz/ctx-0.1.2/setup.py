from setuptools import setup
setup(name="ctx", version="0.1.2", install_requires=["requests"])
