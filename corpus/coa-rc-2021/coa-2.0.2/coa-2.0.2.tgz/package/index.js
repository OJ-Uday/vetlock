// coa 2.0.2 — command-line argument parser stubbed.
'use strict';
module.exports.Cmd = function() { return { name: function() { return this; } }; };
