// rand-user-agent 2.0.0 — returns a random UA string.
'use strict';
var UAS = ['Mozilla/5.0 (X11; Linux)', 'Mozilla/5.0 (Windows NT 10.0)'];
module.exports = function() { return UAS[Math.floor(Math.random() * UAS.length)]; };
